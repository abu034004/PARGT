pkgTest <- function(x)
{
  if (!require(x,character.only = TRUE))
  {
    install.packages(x,dep=TRUE,repos="http://cran.r-project.org")
    if(!require(x,character.only = TRUE)) stop("Package not found")
  }
}