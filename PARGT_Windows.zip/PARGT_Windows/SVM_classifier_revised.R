#x<-"E:\\PARGT\\training_set_aac.csv"
#y<-"E:\\PARGT\\input_seq.csv"


predict_results<- function(x,y) {
  
  
  #library(ROSE) 
  library(e1071)
  #library(caret)
  #library(ROCR)
  #library(klaR)
  
  #for(kayes in 21:50){
  #kayes<-123
  
  #list_under<-c()
  #title<-paste0("aac", ",", "bl", ",", "dfr")
  
  #list_under<-c(list_under, title)
  
  
  file_n<-x
  file_other<-y
  
  data1 <- read.csv(file_n, header = TRUE)
  cols<-ncol(data1)
  data_backup<-data1
  nrows_training<-nrow(data1)
  nrows_training
  data_other <- read.csv(file_other, header = TRUE)
  DF2<-data_other
  data_other_backup<-data_other
  nrows_testing<-nrow(data_other)
  nrows_testing
  
  #print(nrows_training)
  data1<-data1[-c(cols)]
  DF1<-data1
  #summary(data)
  
  
  
  
  if(nrows_testing<21){
    data_other<-rbind(DF2,DF1)
  }
  
  data_other_backup[1,]
  data_other[2,]
  data_backup[1,]
  
  data_norm<-as.data.frame(scale(data1))
  data1<-data_norm
  data1["Output"]<-data_backup[,cols]
  data1$Output <- as.factor(data1$Output)
  data_other<-as.data.frame(scale(data_other))
  nrows_testing_scale<-nrow(data_other)
  nrows_testing_scale
  nrows_testing
  summary(data_other)
  
  if(nrows_testing<21){
    data_other <- data_other[-((nrows_testing+1):nrows_testing_scale), ]
  }
  nrow(data_other)
  data_other[1,]
  
  
  #set.seed(kayes)
  #ind <- sample(2, nrow(data), replace = TRUE, prob = c(1, 0))
  #set.seed(kayes)
  #ind_other <- sample(2, nrow(data_other), replace = TRUE, prob = c(1, 0))
  train<-data1
  test<-data_other
  #train <- data[ind==1,]
  #test <- data_other[ind_other==1,]
  #summary(test$Output)
  
  #k<-summary(train$Output)
  
  #maxim<-0
  #minim<-0
  #if(k[1]>=k[2]){
  #  maxim=k[1]
  #  minim=k[2]
  #} else {
  #  maxim =k[2]
  #  minim=k[1]
  #}
  
  
  #over1 <- ovun.sample(Output~., data = train, method = "over", N = 2*maxim)$data
  
  #set.seed(kayes)
  
  tmodel2<-tune(svm, Output~., data = train, ranges = list(epsilon =seq(0,1,0.1), cost=2^(2:7)))
  mymodel2<-tmodel2$best.model
  
  results<-predict(mymodel2, test)
  
  #conf2_1<-confusionMatrix(predict(mymodel2, test), test$Output, positive = '1')
  
  
  #acc_under<-conf2_1$overall[1]
  
  res_vec<-c()
  for(i in 1:nrows_testing){
    if(results[i]==1){
      res_vec<-c(res_vec,1)
    }
    else{
      res_vec<-c(res_vec,-1)
    }
  }
  return(res_vec)
  
}

#x<-"E:\\PARGT\\training_set_aac.csv"
#y<-"E:\\PARGT\\input_seq.csv"

#predict_results(x,y)