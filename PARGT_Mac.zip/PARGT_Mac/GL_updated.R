
#x<-"E:/OPT4e_windows/out.ss"


extractSSF <- function(x) {


#install.packages("stringr")
#library(stringr)
#install.packages("stringi")
#library(stringi)
#install.packages("dplyr")
#library(dplyr)

list_z<-c()




#add_line1<-paste0("S1",",", "S2",",","S3",",","S4",",","S5",",","S6",",", "GL1", ",", "GL2", ",", "GL3", ",", "LC1.1", ",","LC1.2", ",","LC1.3", ",","LC2.1", ",","LC2.2", ",","LC2.3", ",","LC3.1", ",","LC3.2",",", "LC3.3",",", "LC4.1", ",","LC4.2",",", "LC4.3",",","LC5.1", ",","LC5.2",",", "LC5.3",",","LC6.1", ",","LC6.2",",", "LC6.3",",","LC7.1", ",","LC7.2",",", "LC7.3",",","LC8.1", ",","LC8.2",",", "LC8.3")
#list_z<-c(list_z, add_line1)
#k<-1


#while (k<26){
  file_name<-x
  add_ch<-""
  add_ch_exclude<-""
  flag<-""
  freq<-0
  x<-0
  y<-0
  z<-0
  SH<-0
  SE<-0
  SC<-0
 # print(file_name)
  if(file.exists(file_name)){
  data_psi <- read.table(file_name)
  
  len <-nrow(data_psi)
  #len
  
    for(v in 1:len){
      if(toString(data_psi[v,3])=="H"){
        SH<-SH+v
        SH
        
      }
      if(toString(data_psi[v,3])=="E"){
        SE<-SE+v
        SE
        
      }
      if(toString(data_psi[v,3])=="C"){
        SC<-SC+v
        SC
        
      }
      add_ch<-paste0(add_ch,toString(data_psi[v,3]))
    }
    
    rr <- rle(strsplit(add_ch,"")[[1]])
    rr
    #SH<-sum(rr$lengths[which(rr$values == "H")])
    MH<-max(rr$lengths[which(rr$values == "H")])
    if (MH==-Inf || MH==Inf){
      MH<-0
    }
    
    CMVH<-SH/(len*(len-1))
    NMH<-MH/len
    
    #SE<-sum(rr$lengths[which(rr$values == "E")])
    ME<-max(rr$lengths[which(rr$values == "E")])
    ME
    if (ME==-Inf || ME==Inf){
      ME<-0
    }
    
    CMVE<-SE/(len*(len-1))
    NME<-ME/len
    
    #SC<-sum(rr$lengths[which(rr$values == "C")])
    MC<-max(rr$lengths[which(rr$values == "C")])
    
    CMVC<-SC/(len*(len-1))
    #NMC<-MC/len
    rr_len<-length(rr$values)
    rr_len
    for(v in 1:rr_len){
      if(rr$values[v]!="C")  {
        if(rr$values[v]!= flag){
        add_ch_exclude<-paste0(add_ch_exclude, toString(rr$values[v]))
        flag<-toString(rr$values[v])
        freq<-freq+1
        }
      }
    }
    add_ch_exclude
    freq
    
    #count_EHE<-str_count(add_ch_exclude, fixed("EHE"))
    count_EHE<-gregexpr("(?=EHE)",add_ch_exclude,perl=TRUE)
    count_EHE1<-count_EHE[[1]]
    count_EHE1
    if(count_EHE1<0){
      count_EHE_len<-0
    }
    else{
      count_EHE_len<-length(count_EHE1)
    }
    
    count_EHE_len
    if(freq>2){
      f_EHE<-count_EHE_len/(freq-2)
    }
    else{
      f_EHE<-0
    }
    
    f_EHE
    #add_line<-paste0(toString(CMVH), ",", toString(CMVE), ",", toString(CMVC), ",", toString(NMH), ",", toString(NME), ",", toString(f_EHE))
    list_z<-c(list_z,CMVH, CMVE, CMVC, NMH, NME, f_EHE)
    list_z
    
    for(i in 1:len){
      x<-x+data_psi[i,4]
      y<-y+data_psi[i,5]
      z<-z+data_psi[i,6]
      
    }
    sumx<-x
    sumx
    sumy<-y
    sumy
    sumz<-z
    sumz
    x<-x/len
    x
    y<-y/len
    z<-z/len
    z
 # print(data_psi[2,6])
  # if end bracket
    
  #add_line<-paste0(add_line, ",", toString(x), ",", toString(y), ",", toString(z))
  list_z<-c(list_z, x, y, z)
  
  Num_rows<-floor(len/8)
  for (j in 1:8){
    xl<-0
    yl<-0
    zl<-0
    a<-1+(j-1)*Num_rows
    b<-j*Num_rows
    if(j==8){
      for(s in a:len){
        xl<-xl+data_psi[s,4]
        yl<-yl+data_psi[s,5]
        zl<-zl+data_psi[s,6]
      }
      xl<-xl/(len-a+1)
      yl<-yl/(len-a+1)
      zl<-zl/(len-a+1)
      #add_line<-paste0(add_line, ",", toString(xl), ",", toString(yl), ",", toString(zl))
      list_z<-c(list_z, xl, yl, zl)
      break
      
    }
    
    for(s in a:b){
      xl<-xl+data_psi[s,4]
      yl<-yl+data_psi[s,5]
      zl<-zl+data_psi[s,6]
    }
    xl<-xl/Num_rows
    yl<-yl/Num_rows
    zl<-zl/Num_rows
    #add_line<-paste0(add_line, ",", toString(xl), ",", toString(yl), ",", toString(zl))
    list_z<-c(list_z, xl, yl, zl)
    j<-j+1
  }
  
  #list_z<-c(list_z, add_line)
  }
  
 # k<-k+1
#}
  
 # list_z

return(list_z)

  }
  

